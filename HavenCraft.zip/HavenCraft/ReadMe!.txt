# Minecraft Automatic Backup Script

![License](https://img.shields.io/badge/license-MIT-green)
![PowerShell](https://img.shields.io/badge/PowerShell-5.1-blue)

Automated Minecraft backup script for **Java, CurseForge modpacks, and Bedrock worlds**. Logs backups, keeps 30 days of history, and supports Google Drive syncing.

---

## Features

- Backs up **vanilla Java worlds**  
- Automatically detects and backs up **all CurseForge modded instances**  
- Backs up **Bedrock worlds** if installed  
- Compresses all worlds into a **single zip file**  
- Maintains a **backup log** (`backup_log.txt`) with world counts, modpacks, and zip sizes  
- Keeps backups for **30 days** automatically  
- Supports **Google Drive automatic upload** via folder sync  
- Fully compatible with **modded Minecraft**, including CurseForge modpacks  

---

## Quick Start

1. Download `minecraft_backup.ps1`  
2. Set your backup folder in the script (default: `C:\Users\<USERNAME>\Documents\MinecraftBackupsLocal`)  
3. Run manually in PowerShell:

```powershell
powershell -ExecutionPolicy Bypass -File "C:\Path\To\minecraft_backup.ps1"

    Optionally, schedule automatic daily backups via Task Scheduler (see below)

Folder Structure

MinecraftBackup/
├── minecraft_backup.ps1       # Main backup script
├── README.md                  # This readme file
└── Backups/                   # Local backup folder (user-defined, synced with Google Drive)

Automatic Daily Backup (Task Scheduler)

    Open Task Scheduler → Create Task

    General → Name: Minecraft Daily Backup, check Run with highest privileges

    Trigger → New → Daily → choose preferred time

    Action → Start a program →

        Program/script: powershell

        Arguments:

        -ExecutionPolicy Bypass -File "C:\Users\<USERNAME>\Documents\Scripts\minecraft_backup.ps1"

    Save the task → backups will run automatically daily

Backup Logging

    Every backup creates/updates backup_log.txt in the backup folder.

    Each entry includes:

        Timestamp

        World counts per folder/modpack

        Zip size

    Example log entry:

2026-01-31_15-45-30 - Minecraft Backup Complete
Included:
 - JavaVanilla: 3 worlds, 120 MB
 - CF_ModdedPack1: 2 worlds, 250 MB
 - CF_ModdedPack2: 1 world, 95 MB
 - Bedrock: 0 worlds
Total zip size: 465 MB

Backup Naming

    Zip filenames include timestamp and world/modpack names:

minecraft_backup_YYYY-MM-DD_HH-MM-SS_JavaVanilla_ModdedPack1_Bedrock.zip

    Makes it easy to know what each backup contains without opening the zip

Google Drive Sync

    To automatically upload backups:

        Open Google Drive → Preferences → “Add folder”

        Add your local backup folder

        Enable sync → all new backups will upload automatically

Notes

    Vanilla Java + CurseForge modded worlds are automatically detected

    Bedrock is optional; script skips it if not installed

    Old backups older than 30 days are automatically deleted

    Fully compatible with modded worlds and CurseForge instances

Contributing

Contributions are welcome! Suggestions include:

    Incremental or differential backups

    Email notifications when a backup completes

    Version-specific backup folders

    Additional launcher support

License

This project is licensed under the MIT License. See LICENSE file for details.
Topics

minecraft, modded-minecraft, backup, curseforge, bedrock, powershell