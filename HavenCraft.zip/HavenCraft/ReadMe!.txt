Minecraft Automatic Backup Script

This repository contains a PowerShell script to automatically back up Minecraft worlds for:

Java Edition (vanilla)

CurseForge modded instances

Bedrock Edition (if installed)

The backups are saved to a local folder that can be synced with Google Drive or any other cloud storage solution.

Features

Backs up vanilla Java worlds

Automatically detects and backs up all CurseForge modded instances

Backs up Bedrock worlds if installed

Compresses all worlds into a single zip file

Maintains a backup log (backup_log.txt) with world counts, modpacks, and zip sizes

Keeps backups for 30 days automatically

Supports Google Drive automatic upload via folder sync

Fully compatible with modded Minecraft, including CurseForge modpacks

Folder Structure
MinecraftBackup/
├── minecraft_backup.ps1       # Main backup script
├── README.md                  # This readme file
└── Backups/                   # Local backup folder (user-defined, synced with Google Drive)


You can change the Backups folder location in the script by editing $localBackupFolder.

Requirements

Windows 10 or 11

PowerShell 5.1+ (comes preinstalled on Windows)

Optional: Google Drive or other cloud storage folder to sync backups

Minecraft Java Edition and/or Bedrock installed

Optional: CurseForge modded Minecraft installed

Installation

Create a folder for the script, e.g.:

C:\Users\<USERNAME>\Documents\Scripts\


Copy the minecraft_backup.ps1 script into that folder.

Create a local backup folder where the script will save backups, e.g.:

C:\Users\<USERNAME>\Documents\MinecraftBackupsLocal


If you want backups to automatically upload to Google Drive, add this folder in Google Drive preferences → “Add folder” → enable sync.

Usage
Manual Run

Close Minecraft (optional, recommended)

Open Windows PowerShell

Run the script:

powershell -ExecutionPolicy Bypass -File "C:\Users\<USERNAME>\Documents\Scripts\minecraft_backup.ps1"


The script will create a zip in the local backup folder

A log entry will be added to backup_log.txt

Automatic Daily Backup

Use Windows Task Scheduler:

Open Task Scheduler → Create Task

General → Name: Minecraft Daily Backup, check Run with highest privileges

Trigger → New → Daily → choose preferred time

Action → Start a program →

Program/script: powershell

Arguments:

-ExecutionPolicy Bypass -File "C:\Users\<USERNAME>\Documents\Scripts\minecraft_backup.ps1"


Save the task → backups will now run automatically every day

Backup Logging

Every backup creates/updates backup_log.txt in the backup folder.

Each entry includes:

Timestamp

World counts per folder/modpack

Zip size

Example:

2026-01-31_15-45-30 - Minecraft Backup Complete
Included:
 - JavaVanilla: 3 worlds, 120 MB
 - CF_ModdedPack1: 2 worlds, 250 MB
 - CF_ModdedPack2: 1 world, 95 MB
 - Bedrock: 0 worlds
Total zip size: 465 MB

Notes

Script works for all CurseForge modded instances automatically.

If Bedrock is not installed, it is skipped.

Backups are stored locally first, then uploaded to Google Drive if synced.

Old backups (older than 30 days) are automatically deleted.

Zip filenames include the timestamp and modpack/world names for easy identification:

minecraft_backup_YYYY-MM-DD_HH-MM-SS_JavaVanilla_ModdedPack1_Bedrock.zip

Contributing

Contributions are welcome! You can suggest improvements such as:

Automatic incremental backups

Email notifications for backup completion

Version-specific backup folders

License

This project is open-source and free to use under the MIT License.