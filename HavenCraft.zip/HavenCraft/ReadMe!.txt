# Minecraft Automatic Backup Script

![License: MIT](https://img.shields.io/badge/License-MIT-green)
![PowerShell](https://img.shields.io/badge/PowerShell-5.1-blue)
![Version](https://img.shields.io/badge/version-1.0.0-orange)

Automated Minecraft backup script for **Java Vanilla worlds** and **CurseForge modpacks**.  
Backups are saved locally and optionally synced with Google Drive.

---

## 📌 Features

- ✅ Back up **Java Vanilla worlds**  
- ✅ Automatically back up **all CurseForge modded instances**  
- ✅ Compresses all worlds into a **single ZIP**  
- ✅ Shows **debug output** during backup for full visibility  
- ✅ Keeps backups for configurable days  
- ✅ Fully **user-agnostic** — no username hardcoded  
- ✅ Compatible with modded Minecraft and CurseForge modpacks  

---

## 📂 Folder Structure

MinecraftBackup/
├── backup.ps1 # Main backup script
├── restore.ps1 # Restore script
├── config.psd1 # Settings file
├── README.md # This file
└── Backups/ # Local backup folder (set in config.psd1)


---

## 🚀 Quick Start

1. Place all files (`backup.ps1`, `restore.ps1`, `config.psd1`, `README.md`) in the same folder.  
2. Edit `config.psd1` to set your backup folder and options:

```powershell
@{
    BackupFolder = "C:\Users\jonah\Documents\MinecraftBackupsLocal"
    DryRun = $false
    SeparateZips = $false
    UseGoogleDrive = $false
    KeepLastBackups = 30
    EnableNotifications = $false
    BackupJavaVanilla = $true
    BackupCurseForge = $true
}

    Run a backup manually:

powershell -ExecutionPolicy Bypass -File "backup.ps1"

    The script will print debug messages:

=== Minecraft Backup Starting ===
Backup folder exists: C:\Users\jonah\Documents\MinecraftBackupsLocal
Checking Java Vanilla folder: C:\Users\jonah\AppData\Roaming\.minecraft\saves
Backing up Java Vanilla worlds...
Checking CurseForge Instances folder: C:\Users\jonah\curseforge\minecraft\Instances
Backing up CurseForge modpack: BOOMY
Backing up CurseForge modpack: CobbleGalaxy
Creating ZIP: C:\Users\jonah\Documents\MinecraftBackupsLocal\minecraft_backup_2026-01-31_21-34-02.zip
Backup complete! Saved to: C:\Users\jonah\Documents\MinecraftBackupsLocal\minecraft_backup_YYYY-MM-DD_HH-MM-SS.zip

⏰ Automatic Daily Backup (Task Scheduler)

    Open Task Scheduler → Create Task

    General → Name: Minecraft Daily Backup, check Run with highest privileges

    Trigger → New → Daily → choose your preferred time

    Action → Start a program:

        Program/script: powershell

        Arguments: -ExecutionPolicy Bypass -File "C:\Path\To\backup.ps1"

Backups will now run automatically every day.
⚙️ Config (config.psd1)

    BackupFolder – Path where backups are saved

    DryRun – Test run without copying ($true/$false)

    SeparateZips – Create separate ZIPs per world ($true/$false)

    UseGoogleDrive – Enable Google Drive sync ($true/$false)

    KeepLastBackups – Number of days to retain old backups

    EnableNotifications – Show pop-up or toast notifications ($true/$false)

    BackupJavaVanilla – Backup vanilla Java worlds ($true/$false)

    BackupCurseForge – Backup CurseForge modpacks ($true/$false)

📝 Notes

    Automatically detects Java Vanilla + CurseForge modpacks

    Old backups older than KeepLastBackups are automatically deleted

    Fully compatible with modded worlds

    Script prints debug info for every folder it checks and copies

💡 Restore Instructions

    Run restore.ps1

    Select the backup ZIP you want to restore from

    The script will restore Java Vanilla and any detected CurseForge modpacks automatically

📜 License

This project is licensed under the MIT License.

yaml