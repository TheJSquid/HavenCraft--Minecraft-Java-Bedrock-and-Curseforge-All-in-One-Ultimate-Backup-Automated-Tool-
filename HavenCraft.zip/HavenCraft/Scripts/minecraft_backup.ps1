# ===== Minecraft Backup Script (Zip Names Include Worlds/Modpacks) =====

# Local backup folder (Google Drive sync)
$localBackupFolder = "C:\Users\jonah\Documents\MinecraftBackupsLocal"
$retentionDays = 30
$logFile = "$localBackupFolder\backup_log.txt"

# Minecraft worlds
$javaVanilla = "$env:APPDATA\.minecraft\saves"
$bedrockSaves = "$env:LOCALAPPDATA\Packages\Microsoft.MinecraftUWP_8wekyb3d8bbwe\LocalState\games\com.mojang\minecraftWorlds"
$curseForgeInstances = "$env:APPDATA\.minecraft\instances"

# Ensure local backup folder exists
if (-not (Test-Path $localBackupFolder)) {
    New-Item -ItemType Directory -Path $localBackupFolder | Out-Null
}

# Temp folder for copy
$tempFolder = "$env:TEMP\MinecraftBackupTempFolder"
Remove-Item $tempFolder -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Path $tempFolder | Out-Null

# Track names for zip filename
$backupNames = @()

# Initialize log entry
$timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$logEntry = "$timestamp - Minecraft Backup Complete`nIncluded:`n"

# Copy Vanilla Java worlds
if (Test-Path $javaVanilla) {
    Copy-Item $javaVanilla "$tempFolder\JavaVanilla" -Recurse
    $backupNames += "JavaVanilla"
    $count = (Get-ChildItem $javaVanilla -Directory).Count
    $size = "{0:N2}" -f ((Get-ChildItem $javaVanilla -Recurse | Measure-Object Length -Sum).Sum / 1MB)
    $logEntry += " - JavaVanilla: $count worlds, $size MB`n"
} else {
    $logEntry += " - JavaVanilla: 0 worlds`n"
}

# Copy CurseForge modded worlds
if (Test-Path $curseForgeInstances) {
    Get-ChildItem $curseForgeInstances -Directory | ForEach-Object {
        $instanceSaves = Join-Path $_.FullName "saves"
        if (Test-Path $instanceSaves) {
            Copy-Item $instanceSaves "$tempFolder\CF_$($_.Name)" -Recurse
            $backupNames += $_.Name
            $count = (Get-ChildItem $instanceSaves -Directory).Count
            $size = "{0:N2}" -f ((Get-ChildItem $instanceSaves -Recurse | Measure-Object Length -Sum).Sum / 1MB)
            $logEntry += " - CF_$($_.Name): $count worlds, $size MB`n"
        }
    }
}

# Copy Bedrock worlds if installed
if (Test-Path $bedrockSaves) {
    Copy-Item $bedrockSaves "$tempFolder\Bedrock" -Recurse
    $backupNames += "Bedrock"
    $count = (Get-ChildItem $bedrockSaves -Directory).Count
    $size = "{0:N2}" -f ((Get-ChildItem $bedrockSaves -Recurse | Measure-Object Length -Sum).Sum / 1MB)
    $logEntry += " - Bedrock: $count worlds, $size MB`n"
} else {
    $logEntry += " - Bedrock: 0 worlds`n"
}

# Construct zip filename with modpack names
$namesPart = ($backupNames -join "_")
$zipPath = "$localBackupFolder\minecraft_backup_$timestamp`_$namesPart.zip"

# Compress all copied worlds into zip
Compress-Archive -Path "$tempFolder\*" -DestinationPath $zipPath

# Add zip size to log
$zipSize = "{0:N2}" -f ((Get-Item $zipPath).Length / 1MB)
$logEntry += "Total zip size: $zipSize MB`n`n"

# Append log entry
Add-Content -Path $logFile -Value $logEntry

# Clean temp folder
Remove-Item $tempFolder -Recurse -Force -ErrorAction SilentlyContinue

# Delete old backups
Get-ChildItem $localBackupFolder -Filter "minecraft_backup_*.zip" -ErrorAction SilentlyContinue |
Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-$retentionDays) } |
Remove-Item -Force -ErrorAction SilentlyContinue

# Windows Notification
try {
    [Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] > $null
    $template = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent(2)
    $template.GetElementsByTagName("text")[0].AppendChild($template.CreateTextNode("Minecraft Backup Complete")) > $null
    $template.GetElementsByTagName("text")[1].AppendChild($template.CreateTextNode("Backup saved locally (Google Drive sync enabled)")) > $null
    $toast = [Windows.UI.Notifications.ToastNotification]::new($template)
    [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("Minecraft Backup").Show($toast)
} catch {}
