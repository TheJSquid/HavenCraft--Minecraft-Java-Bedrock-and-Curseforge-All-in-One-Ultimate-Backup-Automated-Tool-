Write-Host "=== Minecraft Backup Starting ==="

# Load config
$configPath = Join-Path $PSScriptRoot 'config.psd1'
if (-not (Test-Path $configPath)) {
    Write-Error 'config.psd1 not found.'
    exit 1
}
$config = Import-PowerShellDataFile $configPath

# Timestamp
$timestamp = Get-Date -Format 'yyyy-MM-dd_HH-mm-ss'
$tempFolder = Join-Path $env:TEMP ("MinecraftBackup_" + $timestamp)
New-Item -ItemType Directory -Force -Path $tempFolder | Out-Null

# Backup root folder
$backupRoot = $config.BackupFolder
if (-not (Test-Path $backupRoot)) {
    Write-Host "Backup folder not found, creating: $backupRoot"
    New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null
} else {
    Write-Host "Backup folder exists: $backupRoot"
}

# === Backup Java Vanilla ===
$javaSaves = Join-Path $env:APPDATA '.minecraft\saves'
Write-Host "Checking Java Vanilla folder: $javaSaves"
if ($config.BackupJavaVanilla -and (Test-Path $javaSaves)) {
    Write-Host "Backing up Java Vanilla worlds..."
    $dest = Join-Path $tempFolder 'JavaVanilla'
    Copy-Item $javaSaves $dest -Recurse -Force
} else {
    Write-Host "No Java Vanilla worlds found or backup disabled."
}

# === Backup CurseForge Modpacks ===
if ($config.BackupCurseForge) {
    $cfPath = Join-Path $env:USERPROFILE 'curseforge\minecraft\Instances'
    Write-Host "Checking CurseForge Instances folder: $cfPath"

    if (Test-Path $cfPath) {
        Get-ChildItem $cfPath -Directory | ForEach-Object {
            $instanceSaves = Join-Path $_.FullName 'saves'
            if (Test-Path $instanceSaves) {
                $safeName = $_.Name -replace '[^a-zA-Z0-9_-]', '_'
                Write-Host "Backing up CurseForge modpack: $($_.Name)"
                Copy-Item $instanceSaves (Join-Path $tempFolder ('CF_' + $safeName)) -Recurse -Force
            } else {
                Write-Host "No saves found for modpack: $($_.Name)"
            }
        }
    } else {
        Write-Host "CurseForge Instances folder not found."
    }
} else {
    Write-Host "CurseForge backup disabled."
}

# === Create ZIP ===
$zipName = "minecraft_backup_$timestamp.zip"
$zipPathFinal = Join-Path $backupRoot $zipName
Write-Host "Creating ZIP: $zipPathFinal"
Compress-Archive -Path (Join-Path $tempFolder '*') -DestinationPath $zipPathFinal -Force

# === Cleanup ===
Remove-Item $tempFolder -Recurse -Force
Write-Host "Backup complete! Saved to: $zipPathFinal"
