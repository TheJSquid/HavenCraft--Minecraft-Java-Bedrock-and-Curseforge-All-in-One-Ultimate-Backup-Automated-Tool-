Write-Host "=== Minecraft Restore Starting ==="

# Load config
$configPath = Join-Path $PSScriptRoot 'config.psd1'
if (-not (Test-Path $configPath)) { Write-Error 'config.psd1 not found.'; exit 1 }
$config = Import-PowerShellDataFile $configPath

# Backup root folder
$backupRoot = $config.BackupFolder
if (-not (Test-Path $backupRoot)) { Write-Error 'Backup folder not found.'; exit 1 }

# List backups
$backups = Get-ChildItem $backupRoot -Filter 'minecraft_backup_*.zip' | Sort-Object CreationTime -Descending
if ($backups.Count -eq 0) { Write-Host 'No backups found'; exit 0 }

Write-Host 'Available backups:'
for ($i=0; $i -lt $backups.Count; $i++) { Write-Host "[$i] $($backups[$i].Name)" }
[int]$choice = Read-Host 'Enter the number of the backup to restore'
if ($choice -lt 0 -or $choice -ge $backups.Count) { Write-Error 'Invalid selection'; exit 1 }

$selectedBackup = $backups[$choice].FullName
$tempRestore = Join-Path $env:TEMP 'MinecraftRestore'
if (Test-Path $tempRestore) { Remove-Item $tempRestore -Recurse -Force }
New-Item -ItemType Directory -Path $tempRestore | Out-Null
Expand-Archive -Path $selectedBackup -DestinationPath $tempRestore -Force

# Restore Java Vanilla
$javaSaves = Join-Path $env:APPDATA '.minecraft\saves'
if (-not (Test-Path $javaSaves)) { New-Item -ItemType Directory -Path $javaSaves | Out-Null }
$javaSource = Join-Path $tempRestore 'JavaVanilla'
if (Test-Path $javaSource) {
    Write-Host 'Restoring Java Vanilla worlds...'
    Copy-Item "$javaSource\*" $javaSaves -Recurse -Force
}

# Restore CurseForge modpacks
$curseForgePaths = @(
    Join-Path $env:USERPROFILE 'curseforge\minecraft\Instances',
    Join-Path $env:PUBLIC 'CurseForge\Minecraft\Instances',
    Join-Path $env:APPDATA '.minecraft\instances'
)

foreach ($cfDir in Get-ChildItem $tempRestore -Directory | Where-Object { $_ -like 'CF_*' }) {
    $modpackName = $cfDir.Name.Substring(3)
    $found = $false
    foreach ($cfPath in $curseForgePaths) {
        $targetSaves = Join-Path $cfPath $modpackName
        if (Test-Path $targetSaves) {
            Write-Host 'Restoring modpack ' + $modpackName
            Copy-Item "$($cfDir.FullName)\*" $targetSaves -Recurse -Force
            $found = $true
            break
        }
    }
    if (-not $found) { Write-Host 'Modpack ' + $modpackName + ' not found. Skipping.' }
}

Remove-Item $tempRestore -Recurse -Force
Write-Host 'Restore complete!'
